package com.example.feelthematch;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.feelthematch.model.MatchItem;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class MatchAdapter extends RecyclerView.Adapter<MatchAdapter.MatchViewHolder> {

    private final List<MatchItem> matchDataList;
    private final Context context;
    private final String turnamen;

    public MatchAdapter(Context context, List<MatchItem> matchDataList, String turnamen) {
        this.context = context;
        this.matchDataList = matchDataList;
        this.turnamen = turnamen;
    }

    @NonNull
    @Override
    public MatchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_match, parent, false);
        return new MatchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MatchViewHolder holder, int position) {
        MatchItem match = matchDataList.get(position);
        
        String homeTeam = match.getTimHome();
        String awayTeam = match.getTimAway();
        String score = match.getSkor();
        String minute = match.getMenit();
        String status = match.getStatus();

        holder.tvItemHome.setText(getFlagEmoji(homeTeam) + " " + homeTeam);
        holder.tvItemAway.setText(getFlagEmoji(awayTeam) + " " + awayTeam);
        
        // Show status instead of score if not yet started
        if (status != null && status.equalsIgnoreCase("SEGERA")) {
            holder.tvItemScore.setText("VS");
            holder.tvItemMinute.setText(match.getTanggal());
        } else {
            holder.tvItemScore.setText(score);
            holder.tvItemMinute.setText(minute);
        }

        // Accessibility Content Description
        String contentDesc = homeTeam + " melawan " + awayTeam + ". ";
        if (status != null && status.equalsIgnoreCase("SEGERA")) {
            contentDesc += "Pertandingan akan segera dimulai pada tanggal " + match.getTanggal() + ". ";
        } else {
            contentDesc += "Skor saat ini " + score + ". Menit ke " + minute + ". Status: " + status + ". ";
        }
        contentDesc += "Ketuk dua kali untuk masuk ke detail.";
        holder.cardItem.setContentDescription(contentDesc);

        // Click Listener for Intent
        holder.cardItem.setOnClickListener(v -> {
            Intent intent = new Intent(context, MatchDetailActivity.class);
            intent.putExtra("TIM_HOME", homeTeam);
            intent.putExtra("TIM_AWAY", awayTeam);
            intent.putExtra("SKOR", score);
            intent.putExtra("MENIT", minute);
            intent.putExtra("STATUS", status);
            intent.putExtra("TANGGAL", match.getTanggal());
            intent.putExtra("KARTU_KUNING", match.getKartuKuning());
            intent.putExtra("PERGANTIAN_PEMAIN", match.getPergantianPemain());
            intent.putExtra("TURNAMEN", turnamen);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return matchDataList != null ? matchDataList.size() : 0;
    }

    public static class MatchViewHolder extends RecyclerView.ViewHolder {
        TextView tvItemMinute, tvItemHome, tvItemScore, tvItemAway;
        MaterialCardView cardItem;

        public MatchViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItemMinute = itemView.findViewById(R.id.tvItemMinute);
            tvItemHome = itemView.findViewById(R.id.tvItemHome);
            tvItemScore = itemView.findViewById(R.id.tvItemScore);
            tvItemAway = itemView.findViewById(R.id.tvItemAway);
            cardItem = itemView.findViewById(R.id.cardItem);
        }
    }
    
    private String getFlagEmoji(String countryName) {
        if (countryName == null) return "🏳️";
        switch (countryName.trim().toLowerCase()) {
            case "prancis": return "🇫🇷";
            case "norwegia": return "🇳🇴";
            case "argentina": return "🇦🇷";
            case "belanda": return "🇳🇱";
            case "inggris": return "🏴";
            case "brasil": return "🇧🇷";
            case "spanyol": return "🇪🇸";
            case "jerman": return "🇩🇪";
            case "amerika serikat": return "🇺🇸";
            case "kolombia": return "🇨🇴";
            default: return "🏳️";
        }
    }
}
