package com.example.feelthematch.api;

import com.example.feelthematch.model.CustomApiResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("346b4a11db1fb89c6e9e")
    Call<CustomApiResponse> getLiveMatches();
}
