package com.example.feelthematch;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.Random;

public class MatchDetailActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextToSpeech textToSpeech;
    private Vibrator vibrator;
    private MediaPlayer mediaPlayer;

    private TextView tvScore;
    private TextView tvMinute;
    private TextView tvStatus;
    private TextView tvBallPosition;
    private TextView tvEventLog;
    private TextView tvMatchTitle;

    private int scoreHome = 0;
    private int scoreAway = 0;
    private int minute = 0;
    
    private String homeTeam = "Tim Home";
    private String awayTeam = "Tim Away";
    private boolean isSimulationActive = false;

    private Handler simulatorHandler = new Handler(Looper.getMainLooper());
    private Handler penaltyHandler = new Handler(Looper.getMainLooper());
    private Random random = new Random();

    private StringBuilder eventLogBuilder = new StringBuilder("Menit 0: Pertandingan dimulai...\n");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match_detail);
        
        // Tangkap Intent
        if (getIntent().hasExtra("TIM_HOME")) {
            homeTeam = getIntent().getStringExtra("TIM_HOME");
        }
        if (getIntent().hasExtra("TIM_AWAY")) {
            awayTeam = getIntent().getStringExtra("TIM_AWAY");
        }

        tvMatchTitle = findViewById(R.id.tvMatchTitle);
        tvScore = findViewById(R.id.tvScore);
        tvMinute = findViewById(R.id.tvMinute);
        tvStatus = findViewById(R.id.tvStatus);
        tvBallPosition = findViewById(R.id.tvBallPosition);
        tvEventLog = findViewById(R.id.tvEventLog);
        Button btnListen = findViewById(R.id.btnListen);

        tvMatchTitle.setText(getFlagEmoji(homeTeam) + " " + homeTeam + " vs " + getFlagEmoji(awayTeam) + " " + awayTeam);

        textToSpeech = new TextToSpeech(this, this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vibratorManager = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            if (vibratorManager != null) {
                vibrator = vibratorManager.getDefaultVibrator();
            }
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }

        try {
            int resId = getResources().getIdentifier("crowd_cheer", "raw", getPackageName());
            if (resId != 0) {
                mediaPlayer = MediaPlayer.create(this, resId);
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(0.4f, 0.4f);
            }
        } catch (Exception e) {
            Log.e("FeelTheMatch", "Crowd cheer media tidak ditemukan. Melanjutkan tanpa suara sorak.");
        }

        btnListen.setOnClickListener(v -> {
            String currentStatus = "Menit ke " + minute + ", skor " + homeTeam + " " + scoreHome + " melawan " + awayTeam + " " + scoreAway;
            speakText(currentStatus);
        });

        startPulseAnimation();
        startSimulator();
    }

    private void startSimulator() {
        isSimulationActive = true;
        try {
            if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
                mediaPlayer.start();
            }
        } catch (Exception e) {}
        
        simulatorHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (minute >= 90) {
                    isSimulationActive = false;
                    tvStatus.clearAnimation();
                    tvStatus.setText("WAKTU NORMAL SELESAI");
                    logEvent("Menit 90: Peluit panjang! Waktu normal selesai.");
                    speakText("Peluit panjang! Waktu normal selesai.");
                    triggerVibration("WHISTLE");
                    
                    simulatorHandler.postDelayed(() -> {
                        if (scoreHome != scoreAway) {
                            String winner = (scoreHome > scoreAway) ? homeTeam : awayTeam;
                            String text = "Pertandingan dimenangkan oleh " + winner + "!";
                            logEvent(text);
                            speakText(text);
                            try { if (mediaPlayer != null && mediaPlayer.isPlaying()) mediaPlayer.pause(); } catch (Exception e) {}
                        } else {
                            logEvent("Skor imbang! Melanjutkan ke babak Adu Penalti.");
                            speakText("Skor imbang! Melanjutkan ke babak Adu Penalti.");
                            tvStatus.setText("FASE ADU PENALTI");
                            startPulseAnimation();
                            startPenaltyShootout();
                        }
                    }, 4000);
                    
                    return;
                }

                minute++;
                tvMinute.setText(minute + "'");
                
                generateRandomEvent();
                
                simulatorHandler.postDelayed(this, 2000);
            }
        }, 2000);
    }
    
    private void generateRandomEvent() {
        int chance = random.nextInt(100); // 0-99
        String affectedTeam = (random.nextBoolean()) ? homeTeam : awayTeam;
        
        if (chance < 15) { // 15% Out of Bounds
            logEvent("Menit " + minute + ": Bola keluar lapangan.");
            triggerVibration("OUT_OF_BOUNDS");
            
        } else if (chance >= 15 && chance < 17) { // 2% Penalty in game
            String eventText = "Menit " + minute + ": Hukuman PENALTI untuk " + affectedTeam + "!";
            logEvent(eventText);
            speakText(eventText);
            triggerVibration("PENALTY_SUSPENSE");
            
            simulatorHandler.postDelayed(() -> {
                if (random.nextInt(100) < 80) { // 80% goal
                    if (affectedTeam.equals(homeTeam)) scoreHome++;
                    else scoreAway++;
                    tvScore.setText(scoreHome + " - " + scoreAway);
                    
                    String goalText = "GOL Penalti untuk " + affectedTeam + "!";
                    logEvent(goalText);
                    speakText(goalText);
                    triggerVibration("GOAL");
                } else {
                    String missText = "Penalti DITEPIS!";
                    logEvent(missText);
                    speakText(missText);
                    triggerVibration("MISS");
                }
            }, 1500); // Wait 1.5s for suspense
            
        } else if (chance >= 17 && chance < 27) { // 10% Goal
            if (affectedTeam.equals(homeTeam)) scoreHome++;
            else scoreAway++;
            tvScore.setText(scoreHome + " - " + scoreAway);
            
            String eventText = "Menit " + minute + ": GOL untuk " + affectedTeam + "!";
            logEvent(eventText);
            speakText(eventText);
            triggerVibration("GOAL");
            
        } else if (chance >= 27 && chance < 32) { // 5% Red Card
            String eventText = "Menit " + minute + ": Kartu Merah untuk pemain " + affectedTeam + "!";
            logEvent(eventText);
            speakText(eventText);
            triggerVibration("RED_CARD");
            
        } else if (chance >= 32 && chance < 42) { // 10% Yellow Card
            String eventText = "Menit " + minute + ": Kartu Kuning untuk pemain " + affectedTeam + ".";
            logEvent(eventText);
            speakText(eventText);
            triggerVibration("YELLOW_CARD");
            
        } else if (chance >= 42 && chance < 52) { // 10% Substitution
            String eventText = "Menit " + minute + ": Pergantian Pemain dari tim " + affectedTeam + ". Pemain cadangan masuk.";
            logEvent(eventText);
            speakText(eventText);
            triggerVibration("SUBSTITUTION");
            
        } else { // 48% Zone Haptics
            int zoneChance = random.nextInt(100);
            if (zoneChance < 50) {
                tvBallPosition.setText("Bola di Tengah");
                triggerVibration("ZONE_1");
            } else if (zoneChance < 80) {
                tvBallPosition.setText("Mendekati Gawang");
                triggerVibration("ZONE_2");
            } else {
                tvBallPosition.setText("Kemelut di Penalti!");
                triggerVibration("ZONE_3");
            }
        }
    }
    
    private int penRound = 1;
    private int penScoreHome = 0;
    private int penScoreAway = 0;

    private void startPenaltyShootout() {
        isSimulationActive = true;
        penaltyHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (penRound > 10) {
                    isSimulationActive = false;
                    tvStatus.clearAnimation();
                    tvStatus.setText("ADU PENALTI SELESAI");
                    String winner = (penScoreHome > penScoreAway) ? homeTeam : (penScoreHome < penScoreAway) ? awayTeam : "Seri";
                    String res = "Adu penalti selesai. Skor penalti: " + homeTeam + " " + penScoreHome + " - " + penScoreAway + " " + awayTeam + ". Pemenang: " + winner;
                    logEvent(res);
                    speakText(res);
                    try { if (mediaPlayer != null && mediaPlayer.isPlaying()) mediaPlayer.pause(); } catch (Exception e) {}
                    return;
                }

                String team = (penRound % 2 != 0) ? homeTeam : awayTeam;
                int teamKickNumber = (penRound + 1) / 2;
                boolean isGoal = random.nextInt(100) < 75; // 75% Goal
                
                String preText = "Penendang " + teamKickNumber + " " + team + "...";
                logEvent(preText);
                speakText(preText);
                triggerVibration("PENALTY_SUSPENSE");

                penaltyHandler.postDelayed(() -> {
                    if (isGoal) {
                        if (team.equals(homeTeam)) penScoreHome++;
                        else penScoreAway++;
                        
                        String goalText = "GOL! Skor Penalti: " + penScoreHome + " - " + penScoreAway;
                        logEvent(goalText);
                        speakText(goalText);
                        triggerVibration("GOAL_SHARP");
                    } else {
                        String missText = "GAGAL! Skor Penalti: " + penScoreHome + " - " + penScoreAway;
                        logEvent(missText);
                        speakText(missText);
                        triggerVibration("MISS");
                    }
                }, 2000); // 2s suspense

                penRound++;
                penaltyHandler.postDelayed(this, 5500); // Next kicker after 5.5s
            }
        }, 5000); // Wait 5s before starting first kick
    }

    private void logEvent(String text) {
        eventLogBuilder.insert(0, text + "\n");
        tvEventLog.setText(eventLogBuilder.toString());
    }
    
    private void speakText(String text) {
        if (textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
    
    private void triggerVibration(String type) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                switch (type) {
                    case "GOAL":
                        long[] timingsGoal = {0, 800, 200, 800};
                        int[] amplitudesGoal = {0, 255, 0, 255};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsGoal, amplitudesGoal, -1));
                        break;
                    case "GOAL_SHARP":
                        long[] timingsGS = {0, 300, 100, 300, 100, 500};
                        int[] amplitudesGS = {0, 255, 0, 255, 0, 255};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsGS, amplitudesGS, -1));
                        break;
                    case "RED_CARD":
                        long[] timingsRed = {0, 150, 100, 150, 100, 150};
                        int[] amplitudesRed = {0, 255, 0, 255, 0, 255};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsRed, amplitudesRed, -1));
                        break;
                    case "YELLOW_CARD":
                        vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                        break;
                    case "SUBSTITUTION":
                        long[] timingsSub = {0, 200, 100, 200};
                        int[] amplitudesSub = {0, 100, 0, 100};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsSub, amplitudesSub, -1));
                        break;
                    case "OUT_OF_BOUNDS":
                        long[] timingsOut = {0, 100, 100, 100};
                        int[] amplitudesOut = {0, 150, 0, 150};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsOut, amplitudesOut, -1));
                        break;
                    case "PENALTY_SUSPENSE":
                        long[] timingsSus = {0, 50, 800, 50, 800, 50};
                        int[] amplitudesSus = {0, 150, 0, 150, 0, 150};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsSus, amplitudesSus, -1));
                        break;
                    case "MISS":
                        vibrator.vibrate(VibrationEffect.createOneShot(100, 100)); // weak
                        break;
                    case "WHISTLE":
                        long[] timingsWhis = {0, 1000, 200, 1000, 200, 1500};
                        int[] amplitudesWhis = {0, 255, 0, 255, 0, 255};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsWhis, amplitudesWhis, -1));
                        break;
                    case "ZONE_1":
                        vibrator.vibrate(VibrationEffect.createOneShot(10, VibrationEffect.DEFAULT_AMPLITUDE));
                        break;
                    case "ZONE_2":
                        vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                        break;
                    case "ZONE_3":
                        long[] timingsZone3 = {0, 50, 50, 100};
                        int[] amplitudesZone3 = {0, 255, 0, 255};
                        vibrator.vibrate(VibrationEffect.createWaveform(timingsZone3, amplitudesZone3, -1));
                        break;
                }
            } else {
                switch (type) {
                    case "GOAL":
                        vibrator.vibrate(new long[]{0, 800, 200, 800}, -1);
                        break;
                    case "GOAL_SHARP":
                        vibrator.vibrate(new long[]{0, 300, 100, 300, 100, 500}, -1);
                        break;
                    case "RED_CARD":
                        vibrator.vibrate(new long[]{0, 150, 100, 150, 100, 150}, -1);
                        break;
                    case "YELLOW_CARD":
                        vibrator.vibrate(300);
                        break;
                    case "SUBSTITUTION":
                        vibrator.vibrate(new long[]{0, 200, 100, 200}, -1);
                        break;
                    case "OUT_OF_BOUNDS":
                        vibrator.vibrate(new long[]{0, 100, 100, 100}, -1);
                        break;
                    case "PENALTY_SUSPENSE":
                        vibrator.vibrate(new long[]{0, 50, 800, 50, 800, 50}, -1);
                        break;
                    case "MISS":
                        vibrator.vibrate(100);
                        break;
                    case "WHISTLE":
                        vibrator.vibrate(new long[]{0, 1000, 200, 1000, 200, 1500}, -1);
                        break;
                    case "ZONE_1":
                        vibrator.vibrate(10);
                        break;
                    case "ZONE_2":
                        vibrator.vibrate(50);
                        break;
                    case "ZONE_3":
                        vibrator.vibrate(new long[]{0, 50, 50, 100}, -1);
                        break;
                }
            }
        } catch (Exception e) {
            Log.e("FeelTheMatch", "Vibrator error: " + e.getMessage());
        }
    }

    private void startPulseAnimation() {
        Animation anim = new AlphaAnimation(0.3f, 1.0f);
        anim.setDuration(800);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        tvStatus.startAnimation(anim);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            Locale indonesianLocale = new Locale("id", "ID");
            int result = textToSpeech.setLanguage(indonesianLocale);

            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("FeelTheMatch", "Bahasa Indonesia tidak didukung di TTS perangkat ini.");
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        simulatorHandler.removeCallbacksAndMessages(null);
        penaltyHandler.removeCallbacksAndMessages(null);
        isSimulationActive = false;
        try {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
            }
        } catch (Exception e) {
            Log.e("FeelTheMatch", "Error pause media: " + e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        simulatorHandler.removeCallbacksAndMessages(null);
        penaltyHandler.removeCallbacksAndMessages(null);
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onDestroy();
    }
    
    private String getFlagEmoji(String countryName) {
        if (countryName == null) return "🏳️";
        switch (countryName.trim().toLowerCase()) {
            case "prancis": return "🇫🇷";
            case "norwegia": return "🇳🇴";
            case "argentina": return "🇦🇷";
            case "belanda": return "🇳🇱";
            case "inggris": return "🏴";
            case "brasil": return "🇧🇷";
            case "spanyol": return "🇪🇸";
            case "jerman": return "🇩🇪";
            case "amerika serikat": return "🇺🇸";
            case "kolombia": return "🇨🇴";
            default: return "🏳️";
        }
    }
}
