package com.example.feelthematch;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.feelthematch.api.ApiClient;
import com.example.feelthematch.api.ApiService;
import com.example.feelthematch.model.CustomApiResponse;
import com.example.feelthematch.model.MatchItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MatchListActivity extends AppCompatActivity {

    private RecyclerView rvMatches;
    private ProgressBar progressBar;
    private TextView tvError;
    private String turnamenTitle = "Pertandingan";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match_list);

        rvMatches = findViewById(R.id.rvMatches);
        progressBar = findViewById(R.id.progressBar);
        tvError = findViewById(R.id.tvError);

        rvMatches.setLayoutManager(new LinearLayoutManager(this));

        fetchLiveMatches();
    }

    private void fetchLiveMatches() {
        progressBar.setVisibility(View.VISIBLE);
        rvMatches.setVisibility(View.GONE);
        tvError.setVisibility(View.GONE);

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        apiService.getLiveMatches().enqueue(new Callback<CustomApiResponse>() {
            @Override
            public void onResponse(Call<CustomApiResponse> call, Response<CustomApiResponse> response) {
                progressBar.setVisibility(View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    CustomApiResponse apiResponse = response.body();
                    turnamenTitle = apiResponse.getTurnamen() + " - " + apiResponse.getPeriode();
                    List<MatchItem> matchItems = apiResponse.getPertandingan();

                    if (matchItems != null && !matchItems.isEmpty()) {
                        MatchAdapter adapter = new MatchAdapter(MatchListActivity.this, matchItems, turnamenTitle);
                        rvMatches.setAdapter(adapter);
                        rvMatches.setVisibility(View.VISIBLE);
                    } else {
                        showError("Data pertandingan kosong.");
                    }
                } else {
                    showError("Gagal memuat data. Kode: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<CustomApiResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                showError("Gagal terhubung: " + t.getMessage());
                Log.e("API_ERROR", "Error: ", t);
            }
        });
    }

    private void showError(String message) {
        tvError.setText(message);
        tvError.setVisibility(View.VISIBLE);
    }
}
