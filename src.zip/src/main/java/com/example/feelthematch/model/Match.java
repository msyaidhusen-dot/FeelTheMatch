package com.example.feelthematch.model;

public class Match {
    private String homeTeam;
    private String awayTeam;
    private String score;
    private String minute;
    private String yellowCards;
    private String substitutions;

    public Match(String homeTeam, String awayTeam, String score, String minute, String yellowCards, String substitutions) {
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.score = score;
        this.minute = minute;
        this.yellowCards = yellowCards;
        this.substitutions = substitutions;
    }

    public String getHomeTeam() { return homeTeam; }
    public String getAwayTeam() { return awayTeam; }
    public String getScore() { return score; }
    public String getMinute() { return minute; }
    public String getYellowCards() { return yellowCards; }
    public String getSubstitutions() { return substitutions; }
}
