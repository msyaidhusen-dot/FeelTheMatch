package com.example.feelthematch.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class CustomApiResponse {
    @SerializedName("periode")
    private String periode;
    
    @SerializedName("turnamen")
    private String turnamen;
    
    @SerializedName("pertandingan")
    private List<MatchItem> pertandingan;

    public String getPeriode() { return periode; }
    public String getTurnamen() { return turnamen; }
    public List<MatchItem> getPertandingan() { return pertandingan; }
}
