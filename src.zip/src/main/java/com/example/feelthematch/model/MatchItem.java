package com.example.feelthematch.model;

import com.google.gson.annotations.SerializedName;

public class MatchItem {
    @SerializedName("tim_home")
    private String timHome;
    
    @SerializedName("tim_away")
    private String timAway;
    
    @SerializedName("skor")
    private String skor;
    
    @SerializedName("menit")
    private String menit;
    
    @SerializedName("status")
    private String status;
    
    @SerializedName("tanggal")
    private String tanggal;
    
    @SerializedName("kartu_kuning")
    private String kartuKuning;
    
    @SerializedName("pergantian_pemain")
    private String pergantianPemain;

    public String getTimHome() { return timHome; }
    public String getTimAway() { return timAway; }
    public String getSkor() { return skor; }
    public String getMenit() { return menit; }
    public String getStatus() { return status; }
    public String getTanggal() { return tanggal; }
    public String getKartuKuning() { return kartuKuning; }
    public String getPergantianPemain() { return pergantianPemain; }
}
